package com.example.imccalculadora

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val calcular : Button = findViewById(R.id.procesar)
        calcular.setOnClickListener {

            val est = estatura.text.toString().toDouble() / 100
            val pes = peso.text.toString().toDouble() / 2.205



            if (pes >= 5000 || est >= 270) {

                Toast.makeText(this, "Ingrese un peso entre 0 y 5000 o ingrese una estatura entre 0 y 270",Toast.LENGTH_SHORT).show()

            } else {
                val IMC= pes / (est * est)
                val re = IMC.toString()
                val intent : Intent = Intent(this, calc2::class.java)
                intent.putExtra("IMC", re)
                startActivity(intent)
            }
        }
    }
}
